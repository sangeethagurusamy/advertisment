package com.learning.miniproject_h1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class App 
{
    public static void main( String[] args )
    {
        Scanner sc=new Scanner(System.in);
        Advertisement add=new Advertisement();
        AdvertisementDAO addao=new AdvertisementDAO();
        System.out.println("enter the number of details");
        int s=Integer.parseInt(sc.nextLine());
        System.out.println("details");
        for(int i=0;i<s;i++)
        {
        	String str=sc.nextLine();
        	String[] string=str.split(",");
        	String str0=string[0];
        	double str1=Double.parseDouble(string[1]);
        	int str2=Integer.parseInt(string[2]);
        	add= new Advertisement(str0,str1,str2);
        }
        System.out.println(add.toString());
        addao.insert(add);
        System.out.println("eneter the id");
        int id=Integer.parseInt(sc.nextLine());
        Advertisement addl= addao.find(id);
        int aa=addl.getNoOfAudienceAttracted();
        System.out.println(aa);
       		if(addl!=null)
		{
			System.out.println("found");
        	System.out.println("enter the update value :");
        	int a=Integer.parseInt(sc.nextLine());
        	addl.setNoOfAudienceAttracted(addl.getNoOfAudienceAttracted()+a);
        
        	System.out.println(addl);
        	addao.update(addl);
		}
		else
		{
			System.out.println("empty");
		}
     
}
    }
