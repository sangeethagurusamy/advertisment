package com.learning.miniproject_h1;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="advertisement")
public class Advertisement {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String advertisementMedia;	
	private Double amountSpent;	
	private Integer noOfAudienceAttracted;
	public Advertisement()
	{
		
	}
	public Advertisement( String advertisementMedia, Double amountSpent, Integer noOfAudienceAttracted) {
		super();
		this.id = id;
		this.advertisementMedia = advertisementMedia;
		this.amountSpent = amountSpent;
		this.noOfAudienceAttracted = noOfAudienceAttracted;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getAdvertisementMedia() {
		return advertisementMedia;
	}
	public void setAdvertisementMedia(String advertisementMedia) {
		this.advertisementMedia = advertisementMedia;
	}
	
	public Double getAmountSpent() {
		return amountSpent;
	}
	public void setAmountSpent(Double amountSpent) {
		this.amountSpent = amountSpent;
	}
	public Integer getNoOfAudienceAttracted() {
		return noOfAudienceAttracted;
	}
	public void setNoOfAudienceAttracted(Integer noOfAudienceAttracted) {
		this.noOfAudienceAttracted = noOfAudienceAttracted;
	}	
	@Override
	public String toString() {
		return "Advertisement [id=" + id + ", advertisementMedia=" + advertisementMedia + ", amountSpent=" + amountSpent
				+ ", noOfAudienceAttracted=" + noOfAudienceAttracted + "]";
	}

}
