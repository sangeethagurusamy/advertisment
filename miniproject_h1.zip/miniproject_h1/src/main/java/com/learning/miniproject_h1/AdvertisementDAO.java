package com.learning.miniproject_h1;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;


public class AdvertisementDAO {
	public void insert(Advertisement ad) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		
    session.beginTransaction();
    session.save(ad);
    session.getTransaction().commit();
    System.out.println("inserted");
    session.close();
	}
	public List<Advertisement> list(){
		 Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction ts=null;
        ts=session.beginTransaction();
       Criteria c = session.createCriteria(Advertisement.class);
       List<Advertisement> lu=c.list();
       return lu;
	}
	public Advertisement find(int id){
        Session session = HibernateUtil.getSessionFactory().openSession();
        Advertisement ad=(Advertisement)session.get(Advertisement.class, id);
        return ad;
       /* Criteria c= session.createCriteria(Advertisement.class);
        c.add(Restrictions.like("id",id));
        List<Advertisement> sl=c.list();
        return sl;	   */
        
       
		
	}
	public void update(Advertisement adu) {
		Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
	    session.update(adu);
	    session.getTransaction().commit();
	    session.close();
	}
}
